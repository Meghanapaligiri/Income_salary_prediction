import streamlit as st
import pandas as pd
import numpy as np
import joblib
import json
import base64

# 1. Load metadata, model, scaler
@st.cache_resource
def load_artifacts():
    with open("features_metadata.json") as f:
        metadata = json.load(f)
    model = joblib.load(metadata['model_path'])
    scaler = joblib.load(metadata['scaler_path'])
    features_order = metadata['feature_names']
    occupation_map = metadata['occupation_mapping']
    education_map = metadata['education_mapping']
    return model, scaler, features_order, occupation_map, education_map

model, scaler, features_order, occupation_map, education_map = load_artifacts()

# 2. Streamlit UI
st.set_page_config(page_title="Income Prediction", page_icon="💰")
st.title("Income Prediction Web App ")
st.markdown("> 🚀 Enter your details below to predict your income :")

with st.form("input_form"):
    col1, col2 = st.columns(2)
    with col1:
        age = st.slider("Age", min_value=17, max_value=90, value=30)
        education = st.selectbox("🎓 Education", list(education_map.keys()))
        occupation = st.selectbox("👩‍💼Occupation", list(occupation_map.keys()))
    with col2:
        gender = st.selectbox("Gender ⚧️", ["Male", "Female"])
        hours_per_week = st.slider("⏰ Work hours per week", min_value=1, max_value=99, value=40)
    submit = st.form_submit_button("Predict")

if submit:
    # 3. Prepare input vector
    input_dict = {
        "age": age,
        "educational-num": education_map[education],
        "occupation": occupation_map[occupation],
        "gender": 1 if gender == "Male" else 0,
        "hours-per-week": hours_per_week
    }

    # 4. Validate and order for model
    missing = set(features_order) - set(input_dict.keys())
    if missing:
        st.error(f"Missing features: {missing}")
    else:
        input_vector = np.array([[input_dict[feat] for feat in features_order]])
        input_scaled = scaler.transform(input_vector)
        prediction = model.predict(input_scaled)[0]
        label = ">50K" if prediction == 1 else "<=50K"
        st.success(f"Predicted income: **{label}**")
        if label == ">50K":
            st.balloons()
            st.success("🎉 Congratulations, you made it!")
        else:
            st.info("keep it up! Upskill or boost hours for a higher income!")

st.caption("_All preprocessing and feature order matches model training. Safe for production!_")
